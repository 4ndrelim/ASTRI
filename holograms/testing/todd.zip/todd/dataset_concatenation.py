import cv2
import numpy as np

loaded_data1 = np.load('random.npy')
loaded_data2 = np.load('radial.npy')


print("loaded_data1 shape: ", loaded_data1.shape)
print("loaded_data2 shape: ", loaded_data2.shape)
# print("loaded_data3 shape: ", loaded_data3.shape)

result = np.concatenate((loaded_data1, loaded_data2), axis=0)
print(loaded_data1.dtype)
print(loaded_data2.dtype)
np.random.shuffle(result)
print(result.dtype)

np.save('dataset.npy', result)#option to save as npy with function